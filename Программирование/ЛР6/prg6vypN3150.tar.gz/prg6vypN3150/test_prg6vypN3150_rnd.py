from prg6vypN3150_rnd import MyPRNG, xor_shift     # Импортировать ваш класс и ГПСЧ (вместо lcg
                                              # должен быть алгоритм, зависящий от варианта)
import pytest


# Тут ваши тесты

@pytest.fixture
def prng() -> MyPRNG:
    return MyPRNG(xor_shift(12345))

def test_next_int(prng: MyPRNG):
    value = prng.next_int()
    assert isinstance(value, int)

def test_next_float(prng: MyPRNG):
    value = prng.next_float()
    assert 0 <= value < 1

def test_next_str(prng: MyPRNG):
    l = 100
    value = prng.next_str(l)
    assert isinstance(value, str)
    assert len(value) == l

def test_shiffle_str(prng: MyPRNG):
    src_str = "Hello, World!"
    value = prng.shuffle_str(src_str)
    assert isinstance(value, str)
    assert sorted(src_str) == sorted(src_str)
    assert len(value) == len(src_str)
    assert value != src_str

# Количество тестов выбирайте самостоятельно,
# но так, чтобы вся необходимая функциональность
# была проверена.
