from prg6vypN3150_rnd import MyPRNG, xor_shift         # Импортировать ваш ГПСЧ и класс MyPRNG
from typing import Any, Callable, Union, Type
import os

# В этом модуле должно содержаться определение декоратора -
# либо в виде функции:
def shuffle_str_ret(prng: MyPRNG, filename: str = None) -> Callable:
    def is_valid_func(obj: Any, name: str) -> bool:
        return callable(obj) and not name.startswith("__") and not name.endswith("__")

    def decorator(obj: Union[Any, Type]) -> Callable:
        import inspect
        if inspect.isclass(obj):
            return decorator_class(obj)
        else:
            return decorator_function(obj) if is_valid_func(obj, obj.__name__) else obj

    def decorator_class(clss) -> Type:
        for name in dir(clss):
            attr: Callable = getattr(clss, name)
            if is_valid_func(attr, name):
                setattr(clss, name, decorator_function(attr))
        return clss

    def decorator_function(func: Callable) -> Callable:
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            def get_time() -> str:
                from datetime import datetime
                return datetime.now().strftime("%d.%m.%y %H:%M:%S")

            func_message: str = f"{get_time()} {func.__name__}(args={args}, kwargs={kwargs}) -> "
            args_messages: list = []
            kwargs_messages: list = []

            new_args: list[str] = []
            for i in range(len(args)):
                if isinstance(args[i], str):
                    new_arg: str = prng.shuffle_str(args[i])
                    args_messages.append(f"{get_time()} {func.__name__}: аргумент {args[i]} (args[{i}]) заменён на {new_arg}")
                    new_args.append(new_arg)
                else:
                    new_args.append(args[i])

            new_kwargs: dict = {}
            for key, value in kwargs.items():
                if isinstance(value, str):
                    new_value: str = prng.shuffle_str(value)
                    new_kwarg: dict = {key: new_value}
                    kwargs_messages.append(f"{get_time()} {func.__name__}: аргумент {value} (kwargs[\"{key}\"]) заменён на {new_kwarg}")
                    new_kwargs.update(new_kwarg)
                else:
                    new_kwargs.update({key: value})
                        
            func_result: Any = func(*new_args, **new_kwargs)
            full_log: str = "\n".join([func_message + str(func_result)] + args_messages + kwargs_messages)

            if filename:
                if not os.path.exists(filename):
                    os.system("touch " + filename)
                with open(filename, "r") as f:
                    prev_data: str = f.read()
                with open(filename, "a") as f:
                    f.write(full_log + "\n")
            else:
                import sys
                sys.stderr.write(full_log + "\n")
                
            return func_result
        return wrapper
    return decorator
