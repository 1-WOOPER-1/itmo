# Вариант 2-2-8-1

# 2 - Алгоритм генерации псевдослучайных чисел
#     регистр сдвига (xor-shift)
#     Шаг 1: x_{i+I} ^= x_i >> a
#     Шаг 2: x_{i+I} ^= x_i << b
#     Шаг 3: x_{i+I} ^= x_i >> c
#     ^= - исключающее или с присваиванием
#     << - сдвиг влево
#     >> - сдвиг вправо

# 2 - Способ реализации ГПСЧ
#     Генератор (yield)

# 8 - Действие, выполняемое декоратором
#     @shuffle_str_ret Декоратор должен заменить любые строки, которые
#     передаются как позиционные или именованные
#     аргументы в функцию или метод, на строки, в
#     которых символы исходных строк переставлены в
#     случайном (с помощью ГПСЧ) порядке.

# 1 - Способ реализации декоратора
#     Функция 



from abc import ABC, abstractmethod
from collections.abc import Generator

# В этом модуле должно содержаться определение ГПСЧ -
# либо в виде генератора:
def xor_shift(state: int = 1, a: int = 13, b: int = 7, c: int = 17) -> Generator[int]:
    # Замечание: аннотацию Iterator[int] с Python 3.13 можно заменить на Generator[int]
    while True:
        state ^= (state << a) & 0xFFFFFFFFFFFFFFFF
        state ^= (state >> b) & 0xFFFFFFFFFFFFFFFF
        state ^= (state << c) & 0xFFFFFFFFFFFFFFFF
        yield state & 0xFFFFFFFFFFFFFFFF


class PRNGBase(ABC):
    @abstractmethod
    def next_int(self) -> int:
        """Возвращает случайное целое число"""
        ...

    @abstractmethod
    def next_float(self) -> float:
        """Возвращает случайное вещественное число в диапазоне от 0.0 до 1.0 (не включая)"""
        ...

    @abstractmethod
    def next_str(self) -> str:
        """Возвращает случайную последовательность символов"""
        ...

    @abstractmethod
    def shuffle_str(self, src: str) -> str:
        """Получает строку src и возвращает строку, содержащую символы из src, переставленные в случайном порядке"""
        ...


class MyPRNG(PRNGBase):
    def __init__(self, gen: Generator):
        self.gen = iter(gen)

    def next_int(self) -> int:
        return next(self.gen)

    def next_float(self) -> float:
        res: float = next(self.gen) / 2**64
        return res

    def next_str(self, length: int = 10) -> str:
        def random_chr():
            return chr(int(self.next_float() * (127 - 32) + 32))
        res: str = "".join(random_chr() for _ in range(length))
        return res

    def shuffle_str(self, src: str) -> str:
        res: str = ""
        while len(src) > 0:
            c: int = int(self.next_int() % len(src))
            res += src[c]
            src = src[:c] + src[c+1:]
        return res
