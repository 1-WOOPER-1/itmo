from prg6vypN3150_rnd import MyPRNG, xor_shift         # Импортировать ваш ГПСЧ и класс MyPRNG
from prg6vypN3150_subst import shuffle_str_ret             # Импортировать ваш декоратор
import pytest

# Тут ваши тесты

@pytest.fixture
def prng() -> MyPRNG:
    return MyPRNG(xor_shift(124))

def test_decorator_args(prng: MyPRNG):
    @shuffle_str_ret(prng)
    def greeting(name, surname):
        return f"Hello, {name} {surname}!"
    
    name, surname = "Vladimir", "Pakhomov" 
    res = greeting(name, surname)
    assert sorted(res) == sorted(f"Hello, {name} {surname}!")
    assert res != f"Hello, {name} {surname}!"

def test_decorator_kwargs(prng: MyPRNG):
    @shuffle_str_ret(prng)
    def combine_data(hostname="", login="", password=""):
        return {key: value for key, value in {
            "hostname": hostname,
            "login": login,
            "password": password
            }.items()
        }
    
    data = {
        "hostname": "localhost",
        "login": "vladimir",
        "password": "12345",
        }
    res = combine_data(data["hostname"], data["login"], data["password"])
    assert res != data

def test_decorator_ignore_non_str(prng: MyPRNG):
    @shuffle_str_ret(prng)
    def sum_int(*args):
        return f"sum = {sum(x for x in args if isinstance(x, int))} from {args}"
    
    data = (1, 2, 3, 4, 5, "123")
    res = sum_int(*data)
    assert res != f"sum = {sum(x for x in data if isinstance(x, int))} from {data}"

def test_decorator_with_class(prng: MyPRNG):
    @shuffle_str_ret(prng)
    class Funcs:
        def __init__(self, *args):
            self.args = list(*args)
        
        def get_args(self):
            return self.args

        def update_args(self, *new_args):
            self.args.extend(new_args)
            return self.args
    
    data = [1, 2, 3, "231", "True"]
    f = Funcs(data)
    assert f.get_args() == data

    new_data = ("Hello", "World")
    res = f.update_args(*new_data)
    data.extend(new_data)
    assert res != data

# Количество тестов выбирайте самостоятельно,
# но так, чтобы вся необходимая функциональность
# была проверена.
