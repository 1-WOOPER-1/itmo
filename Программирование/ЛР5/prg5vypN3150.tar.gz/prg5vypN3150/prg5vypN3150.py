class FormatError(Exception):
    def __init__(self, message='Неверный формат IPv4'):
        super().__init__(message)

class UndoError(Exception):
    def __init__(self, message='Невозможно выполнить undo'):
        super().__init__(message)

class RedoError(Exception):
    def __init__(self, message='Невозможно выполнить redo'):
        super().__init__(message)


# Необходимо выбрать один из классов (см. Табл. 1 в задании)

#class MyList(list):
#class MySet(set):
#class MyDict(dict):


class MyDict(dict):
    # Тут ваш код

    def __init__(self, iterable={}):
        super().__init__(iterable)
        self.check_type(iterable)
        self.undo_stack = [super().copy()]
        self.redo_stack = []

    '''Проверка формата строки'''
    def check_format(self, value):
        import re
        part = r'((25[0-5])|(2[0-4]\d)|(1\d\d)|([1-9]?\d))'
        if not isinstance(value, str):
            raise TypeError()
        if not re.match(fr'^{part}\.{part}\.{part}\.{part}$', value):
            raise FormatError()

    '''Проверка типа данных'''
    def check_type(self, iterable):
        if isinstance(iterable, dict):
            for key in iterable.keys():
                if isinstance(key, str):
                    self.check_format(key)
                else:
                    raise TypeError('Ошибка типа данных')
        elif isinstance(iterable, list) or isinstance(iterable, tuple) or isinstance(iterable, set):
            for el in iterable:
                if isinstance(el, tuple) and len(el) == 2:
                    if isinstance(el[0], str):
                        self.check_format(el[0])
                    else:
                        raise TypeError('Ошибка типа данных')
                else:
                    raise TypeError('Ошибка типа данных')
        else:
            raise TypeError('Ошибка типа данных')
    
    '''Команда undo'''
    def undo(self):
        if len(self.undo_stack) == 1:
            raise UndoError()
        self.redo_stack.append(self.undo_stack[-1].copy())
        del self.undo_stack[-1]
        super().clear()
        super().update(self.undo_stack[-1].copy())

    '''Команда redo'''
    def redo(self):
        if len(self.redo_stack) == 0:
            raise RedoError()
        self.undo_stack.append(self.redo_stack[-1].copy())
        del self.redo_stack[-1]
        super().clear()
        super().update(self.undo_stack[-1].copy())
    
    '''Переопределение методов словаря'''
    def __setitem__(self, key, value):
        self.check_format(key)
        super().__setitem__(key, value)
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
    
    def __delitem__(self, key):
        super().__delitem__(key)
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
    
    def __ior__(self, iterable):
        self.check_type(iterable)
        super().update(iterable)
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
        return self
    
    def __or__(self, iterable):
        self.check_type(iterable)
        new = MyDict()
        new.update(self.copy())
        new.undo_stack = self.undo_stack.copy()
        new.redo_stack = self.redo_stack.copy()
        new.update(iterable)
        return new
    
    def update(self, iterable):
        self.check_type(iterable)
        super().update(iterable)
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
    
    def pop(self, key):
        del_key = super().pop(key)
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
        return del_key

    def popitem(self):
        del_item = super().popitem()
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()
        return del_item
    
    def setdefault(self, key, default):
        self.undo_stack.append(super().copy())
        super().setdefault(key, default)
        self.redo_stack.clear()
        return default

    def clear(self):
        super().clear()
        self.undo_stack.append(super().copy())
        self.redo_stack.clear()


# Вариант 4-1
# 4 - dict (ограничение на ключи словаря)
# 1 - IPv4
