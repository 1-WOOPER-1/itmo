from prg5vypN3150 import FormatError, UndoError, RedoError, MyDict    # Импортировать ваш класс
import pytest


# Тут ваши тесты


def test_init_dict():
    d1 = MyDict({'192.168.0.1': 12, '8.8.8.8': True})
    d2 = MyDict([('255.255.255.0', 'Hello'), ('0.0.0.0', 123.21)])
    d3 = MyDict()
    assert d1['192.168.0.1'] == 12
    assert d2['0.0.0.0'] == 123.21
    assert d3 == {}

def test_check_format():
    with pytest.raises(FormatError):
        d = MyDict({'123.355.3.1': 213})
        d = MyDict({'123.355.3.1.1'})

def test_check_type():
    with pytest.raises(TypeError):
        d = MyDict([(255.12, 90)])
        d = MyDict([['2.2.2.2', False]])
        d = MyDict(12390)

def test_setitem():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True})
    d['8.8.8.8'] = 5
    d['7.7.7.7'] = 90
    assert d['8.8.8.8'] == 5
    assert d['7.7.7.7'] == 90
    with pytest.raises(FormatError):
        d['256.0.0.0'] = 21

def test_ior_and_or():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True})
    d |= {'5.5.5.5': 321}
    assert '5.5.5.5' in d
    d | {'4.4.4.4': 432}
    assert '4.4.4.4' not in d

def test_pop_and_popitem():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True, '5.5.5.5': False})
    del_key = d.pop('8.8.8.8')
    assert del_key not in d
    assert del_key == True
    del_item = d.popitem()
    assert ('5.5.5.5', False) == del_item

def test_update_and_setdefault():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True, '5.5.5.5': False})
    d.update([('2.2.2.2', '1'), ('1.2.3.4', '3')])
    assert '2.2.2.2' in d and '1.2.3.4' in d
    d.setdefault('8.8.8.8', 'True')
    d.setdefault('9.8.7.6', 'True')
    assert d['8.8.8.8'] == True
    assert d['9.8.7.6'] == 'True'

def test_delitem_and_clear():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True, '5.5.5.5': False})
    del d['8.8.8.8']
    assert '8.8.8.8' not in d
    d.clear()
    assert len(d) == 0

def test_undo_and_redo():
    d = MyDict({'192.168.0.1': 12, '8.8.8.8': True, '5.5.5.5': False})
    cp = d.copy()
    del d['8.8.8.8']
    cp_r = d.copy()
    d.undo()
    assert cp == d
    d.redo()
    assert cp_r == d
    with pytest.raises(UndoError):
        d.undo()
        d.undo()
    with pytest.raises(RedoError):
        d.redo()
        d.redo()



# Количество тестов выбирайте самостоятельно,
# но так, чтобы вся необходимая функциональность
# была проверена.
