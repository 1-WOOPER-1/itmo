#include <stdlib.h>
#include <stdio.h>

#include <stdint.h>
#include <inttypes.h>
#include <time.h>
#include <unistd.h>


void print_bin(uint16_t number);
uint16_t circular_shift(uint16_t number, int N);

// Вывод двоичного числа с пробелами
void print_bin(uint16_t number) {
    for (int i = sizeof(number) * 8 - 1; i >= 0; i--) {
        int bit = (number >> i) & 1;
        printf("%d", bit);
        if (i % 8 == 0 && i != 0) {
            printf(" ");
        }
    }
    printf("\n");
}

// Циклический сдвиг со свёрткой байтов
uint16_t circular_shift(uint16_t number, int N) {
    uint16_t result = 0;
    for (int i = 0; i < (int) sizeof(number); i++) {
        uint8_t byte = (number >> (i * 8)) & 0xFF;
        // Извлечение старшей и младшей тетрады
        uint8_t high_tetr = byte >> 4;
        uint8_t low_tetr = byte & 0xF;
        // Циклический сдвиг тетрад
        high_tetr = ((high_tetr >> N) | (high_tetr << (4 - N))) & 0xF;
        low_tetr = ((low_tetr << N) | (low_tetr >> (4 - N))) & 0xF;
        
        uint8_t new_byte = (high_tetr << 4) | low_tetr;
        result |= (new_byte << (i * 8));
    }
    return result;
}

int main(int argc, char *argv[]) {
    // Проверка запуска с переменной среды, включающей отладочный вывод.
    char *DEBUG = getenv("LAB1DEBUG");
    if (DEBUG) {
        fprintf(stderr, "Включен вывод отладочных сообщений\n");
    }

    srand(time(NULL) + getpid());
    uint16_t number;
    int N = rand() % 4;
    char *endptr;
    if (argc == 1) {                            // Если число не передано, то генерируем рандомное
        number = rand() & UINT16_MAX;
    } else if (argc == 2) {                     // Если число передано, то 
        number = strtol(argv[1], &endptr, 10);  // проверяем на валидность
        if (endptr == argv[1] || *endptr != '\0') {
            fprintf(stderr, "Ошибка: '%s' не является целым числом.\n", argv[1]);
            return EXIT_FAILURE;
        }

    } else {
        fprintf(stderr, "Usage: %s [число]\n", argv[0]);
        return EXIT_FAILURE;
    }

    printf("N: %d\n", N);
    print_bin(number);
    print_bin(circular_shift(number, N));

    return EXIT_SUCCESS;
}
