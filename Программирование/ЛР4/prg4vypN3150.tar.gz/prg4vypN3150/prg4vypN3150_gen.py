#!/usr/bin/python3
from sys import exit
from random import randint
from argparse import ArgumentParser
from struct import pack

def generate_isbn13():
    prefix = str(randint(978, 979))
    group = str(randint(0, 5))
    publisher = str(randint(0, 999)).zfill(3)
    title = str(randint(0, 99999)).zfill(5)
    
    digits = prefix + group + publisher + title
    total = sum(int(digits[i]) if i % 2 == 0 else int(digits[i]) * 3 for i in range(len(digits)))
    checksum = (10 - (total % 10)) % 10
    return f"{prefix}-{group}-{publisher}-{title}-{checksum}"

def main():
    parser = ArgumentParser()
    parser.add_argument("-v", action="store_true")
    parser.add_argument("-n", type=int)
    parser.add_argument("filename", nargs="?")
    args = parser.parse_args()

    author = "Пахомов Владимир Юрьевич, гр. N3150\nВариант: 1-9-10-2";

    if args.v:
        print(author)
        exit(0)

    if not args.filename:
        print("Ошибка: выходной файл не задан.")
        exit(1)

    num_strings = args.n if args.n is not None else randint(10, 1000)
    if num_strings <= 0:
        print("Ошибка: количество строк должно быть положительным.")
        exit(2)

    strings = [generate_isbn13().encode("utf-8") + b"\x00" for _ in range(num_strings)]

    data_size = randint(0, 1024)
    data = bytes(randint(0, 255) for _ in range(data_size))

    offset = 4
    string_positions = []
    current_pos = offset
    for s in strings:
        string_positions.append(current_pos)
        current_pos += len(s)

    data_pos = current_pos
    current_pos += len(data)

    index_positions = []
    indices = []
    for i in range(num_strings):
        index_positions.append(current_pos)
        indices.append(i)
        current_pos += 2

    # Запись в файл
    try:
        with open(args.filename, "wb") as f:
            f.write(pack("<I", offset))
            for s in strings:
                f.write(s)
            f.write(data)
            for idx in indices:
                f.write(pack("<H", idx))

        print(f"Файл'{args.filename}' успешно сгенерирован.")
        exit(0)

    except Exception as e:
        print(f"Ошибка записи в файл: {e}")
        exit(3)

if __name__ == "__main__":
    main()