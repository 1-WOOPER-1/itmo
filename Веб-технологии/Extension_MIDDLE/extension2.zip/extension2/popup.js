const button = document.getElementById("generate-btn");
const linkInput = document.getElementById("link-input");
const qrCodeImg = document.getElementById("qr-code");
const statusMessage = document.getElementById("status-message");

let blob;

function copyToClipboard() {
  if (!blob) return;
  navigator.clipboard.write([
    new ClipboardItem({
      "image/png": blob,
    }),
  ]);
}

function validateURL(link) {
  try {
    const url = new URL(link);
    return url.protocol && url.hostname;
  } catch (e) {
    return false;
  }
}

async function fetchQR(link) {
  const qrURL = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${link}`;

  try {
    const response = await fetch(qrURL);
    blob = await response.blob();
    const imgURL = URL.createObjectURL(blob);

    qrCodeImg.src = imgURL;

    statusMessage.textContent = "Нажмите для копирования QR-кода";
  } catch (e) {
    statusMessage.textContent = "Ошибка загрузки QR-кода: " + e.message;
  }
}

button.addEventListener("click", () => {
  const link = linkInput.value;

  if (!validateURL(link)) {
    statusMessage.textContent = "Пожалуйста, введите корректную ссылку";
    qrCodeImg.src = "";
    return;
  } else {
    fetchQR(link);
  }
});

qrCodeImg.addEventListener("mouseover", () => {
  qrCodeImg.title = "Скопировать";
});

qrCodeImg.addEventListener("click", async () => {
  if (!blob || qrCodeImg.src === "") return;
  copyToClipboard();
  statusMessage.textContent = "QR-код скопирован в буфер обмена!";
});

linkInput.addEventListener("input", () => {
  if (validateURL(linkInput.value)) {
    button.disabled = false;
  } else {
    button.disabled = true;
  }
});
