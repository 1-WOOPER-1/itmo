const button = document.getElementById("generate-btn");
const min_value = document.getElementById("min-value");
const max_value = document.getElementById("max-value");
const result = document.getElementById("result");

async function copyToClipboard(string) {
  try {
    await navigator.clipboard.writeText(string);
  } catch (e) {
    console.error("Не удалось скопировать в буфер обмена: ", e);
  }
}

button.addEventListener("click", async () => {
  const min = parseInt(min_value.value);
  const max = parseInt(max_value.value);

  if (isNaN(min) || isNaN(max)) {
    result.textContent = "Пожалуйста, введите корректные числа.";
    return;
  }

  if (min > max) {
    result.textContent =
      "Минимальное значение не может быть больше максимального.";
    return;
  }

  const random_number = Math.floor(Math.random() * (max - min + 1)) + min;
  result.textContent = `Случайное число ${random_number} скопировано`;

  copyToClipboard(random_number.toString());
});
