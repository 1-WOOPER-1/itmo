const urlParams = new URLSearchParams(window.location.search);
const domain = urlParams.get("domain");
const domainName = document.getElementById("domain-name");
domainName.textContent = domain || "этого ресурса";
