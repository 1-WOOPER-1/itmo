const browserAPI = typeof browser !== "undefined" ? browser : chrome;

const openOptionsBtn = document.getElementById("open-options-btn");
const timeSpentSpan = document.getElementById("time-spent");
const timeLeftSpan = document.getElementById("time-left");

openOptionsBtn.addEventListener("click", () => {
  if (browserAPI.runtime.openOptionsPage) {
    browserAPI.runtime.openOptionsPage();
  } else {
    window.open(browserAPI.runtime.getURL("settings/options.html"));
  }
});

function getDomain(url) {
  if (!url) return null;

  let cleanUrl = url.trim();
  if (!cleanUrl.includes("://")) {
    cleanUrl = "http://" + cleanUrl;
  }

  try {
    const parsed = new URL(cleanUrl);
    return parsed.hostname.replace(/^www\./, "").toLowerCase();
  } catch (e) {
    return null;
  }
}

function findMatchRule(visitedDomain, urls) {
  if (!visitedDomain || !Array.isArray(urls)) return null;
  return urls.find((rule) => {
    const limitDomain = getDomain(rule.url);
    if (!limitDomain) return false;
    return (
      visitedDomain === limitDomain || visitedDomain.endsWith("." + limitDomain)
    );
  });
}

async function updatePopup() {
  browserAPI.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (tabs.length === 0) return;

    const domain = getDomain(tabs[0].url);
    if (!domain) {
      timeSpentSpan.textContent = "—";
      timeLeftSpan.textContent = "—";
      return;
    }

    const syncData = await browserAPI.storage.sync.get("urls");
    const localData = await browserAPI.storage.local.get("stats");

    const urls = syncData.urls || [];
    const stats = localData.stats || {};

    const rule = findMatchRule(domain, urls);

    if (rule) {
      const limitDomain = getDomain(rule.url);
      const spentSeconds = stats[limitDomain] || 0;
      const spentMinutes = (spentSeconds / 60).toFixed(1);
      const limitMinutes = rule.time;
      const leftMinutes = Math.max(0, limitMinutes - spentSeconds / 60).toFixed(
        1,
      );

      timeSpentSpan.textContent = spentMinutes;
      timeLeftSpan.textContent = leftMinutes;
    } else {
      timeSpentSpan.textContent = "  —  ";
      timeLeftSpan.textContent = "∞";
    }
  });
}

updatePopup();
