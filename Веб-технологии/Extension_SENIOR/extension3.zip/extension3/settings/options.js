const browserAPI = typeof browser !== "undefined" ? browser : chrome;

const urlList = document.getElementById("url-items");
const saveBtn = document.getElementById("save-btn");
const addUrlBtn = document.getElementById("add-url-btn");

class UrlItem {
  constructor(url, time) {
    this.url = url;
    this.time = time;
    this.li = document.createElement("li");
    this.li.className = "url-item";

    const urlInput = document.createElement("input");
    urlInput.type = "text";
    urlInput.placeholder = "Ссылка";
    urlInput.value = url;

    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "❌";
    deleteBtn.addEventListener("click", () => this.li.remove());

    const timeInput = document.createElement("input");
    timeInput.type = "number";
    timeInput.min = "0";
    timeInput.placeholder = "Время в минутах";
    timeInput.value = String(time) || "0";

    this.li.appendChild(urlInput);
    this.li.appendChild(deleteBtn);
    this.li.appendChild(timeInput);
  }
}

browserAPI.storage.sync.get("urls").then((result) => {
  const urls = result.urls || [];
  urls.forEach(({ url, time }) => {
    const urlItem = new UrlItem(url, time);
    urlList.appendChild(urlItem.li);
  });
});

function saveSettings() {
  const urls = [];
  urlList.querySelectorAll(".url-item").forEach((li) => {
    const urlInput = li.querySelector("input[type='text']");
    const timeInput = li.querySelector("input[type='number']");
    const url = urlInput.value.trim();
    const time = parseInt(timeInput.value, 10) || 0;
    if (url !== "") {
      urls.push({ url, time });
    }
  });
  browserAPI.storage.sync.set({ urls: urls });
}

function addUrl() {
  const newUrlItem = new UrlItem("", 0);
  urlList.appendChild(newUrlItem.li);
}

saveBtn.addEventListener("click", saveSettings);
addUrlBtn.addEventListener("click", addUrl);
