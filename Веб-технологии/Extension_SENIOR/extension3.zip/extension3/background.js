const browserAPI = typeof browser !== "undefined" ? browser : chrome;

let activeTabId = null;
let activeDomain = null;
let timerInterval = null;

function getDomain(url) {
  if (!url) return null;

  let cleanUrl = url.trim();
  if (!cleanUrl.includes("://")) {
    cleanUrl = "http://" + cleanUrl;
  }

  try {
    const parsed = new URL(cleanUrl);
    return parsed.hostname.replace(/^www\./, "").toLowerCase();
  } catch (e) {
    return null;
  }
}

function findMatchRule(visitedDomain, urls) {
  if (!visitedDomain || !Array.isArray(urls)) return null;
  return urls.find((rule) => {
    const limitDomain = getDomain(rule.url);
    if (!limitDomain) return false;
    return (
      visitedDomain === limitDomain || visitedDomain.endsWith("." + limitDomain)
    );
  });
}

async function checkLimitAndBlock(tabId, domain) {
  if (!domain) return;

  const syncData = await browserAPI.storage.sync.get("urls");
  const localData = await browserAPI.storage.local.get([
    "stats",
    "lastResetDate",
  ]);

  const urls = syncData.urls || [];
  const stats = localData.stats || {};
  const lastResetDate = localData.lastResetDate;

  const today = new Date().toDateString();
  if (lastResetDate !== today) {
    await browserAPI.storage.local.set({ stats: {}, lastResetDate: today });
  }

  const rule = findMatchRule(domain, urls);
  if (rule) {
    const limitDomain = getDomain(rule.url);
    const spentSeconds = stats[limitDomain] || 0;
    const allowedSeconds = rule.time * 60;

    if (spentSeconds >= allowedSeconds) {
      blockTab(tabId, limitDomain);
    }
  }
}

function blockTab(tabId, domain) {
  const blockUrl =
    browserAPI.runtime.getURL("blocked/blocked.html") +
    `?domain=${encodeURIComponent(domain)}`;
  browserAPI.tabs.update(tabId, { url: blockUrl });
}

function startTracking() {
  if (timerInterval) clearInterval(timerInterval);

  timerInterval = setInterval(async () => {
    if (!activeDomain || !activeTabId) return;

    const syncData = await browserAPI.storage.sync.get("urls");
    const localData = await browserAPI.storage.local.get([
      "stats",
      "lastResetDate",
    ]);

    const urls = syncData.urls || [];
    let stats = localData.stats || {};
    const today = new Date().toDateString();

    if (localData.lastResetDate !== today) {
      stats = {};
      await browserAPI.storage.local.set({ stats: {}, lastResetDate: today });
    }
    const rule = findMatchRule(activeDomain, urls);

    if (rule) {
      const limitDomain = getDomain(rule.url);
      stats[limitDomain] = (stats[limitDomain] || 0) + 1;

      await browserAPI.storage.local.set({ stats });

      if (stats[limitDomain] >= rule.time * 60) {
        blockTab(activeTabId, limitDomain);
      }
    }
  }, 1000);
}

async function updateActiveTab() {
  browserAPI.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
    if (tabs.length === 0) {
      activeTabId = null;
      activeDomain = null;
      return;
    }
    const tab = tabs[0];
    activeTabId = tab.id;
    activeDomain = getDomain(tab.url);

    if (activeDomain) {
      await checkLimitAndBlock(activeTabId, activeDomain);
    }
  });
}

browserAPI.tabs.onActivated.addListener(updateActiveTab);
browserAPI.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" || changeInfo.url) {
    updateActiveTab();
  }
});

browserAPI.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === browserAPI.windows.WINDOW_ID_NONE) {
    activeDomain = null;
    activeTabId = null;
  } else {
    updateActiveTab();
  }
});

startTracking();
