#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <fcntl.h>
#include <dirent.h>


#define MAX_PATH 4096
#define BUFFER_SIZE 4096


struct linux_dirent64 {
    unsigned long long d_ino;
    long long          d_off;
    unsigned short     d_reclen;
    unsigned char      d_type;
    char               d_name[];
};


typedef struct StackNode {
    char path[MAX_PATH];
    struct StackNode *next;
} StackNode;

void push(StackNode **top, const char *path) {
    StackNode *node = malloc(sizeof(StackNode));
    if (!node) {
        perror("malloc");
        exit(1);
    }
    strncpy(node->path, path, MAX_PATH - 1);
    node->path[MAX_PATH - 1] = '\0';

    node->next = *top;
    *top = node;
}

char *pop(StackNode **top) {
    if (*top == NULL) return NULL;
    StackNode *node = *top;
    char *path = strdup(node->path);
    if (!path) {
        perror("strdup");
        exit(1);
    }
    *top = node->next;
    free(node);
    return path;
}

int hexToBytes(const char *hexStr, unsigned char *bytes) {
    if (strncmp(hexStr, "0x", 2) != 0) return -1;
    const char *p = hexStr + 2;
    int length = strlen(p);
    if (length == 0 || length % 2 != 0) return -1;

    int byteCount = 0;
    for (int i = 0; i < length; i += 2) {
        unsigned int temp;
        if (sscanf(p + i, "%2x", &temp) != 1) return -1;
        bytes[byteCount++] = (unsigned char)temp;
    }
    return byteCount;
}

int search(const char *filepath, unsigned char *target, int targetLength, int debug) {
    int fd = open(filepath, O_RDONLY);
    if (fd < 0) return 0;

    unsigned char buffer[BUFFER_SIZE];
    ssize_t n;
    int found = 0;
    long totalOffset = 0;

    while ((n = read(fd, buffer, BUFFER_SIZE)) > 0) {
        for (int i = 0; i <= n - targetLength; i++) {
            if (memcmp(&buffer[i], target, targetLength) == 0) {
                if (debug) fprintf(stderr, "Файл %s: Найдено совпадение %ld\n", filepath, totalOffset + i);
                found = 1;
                break;
            }
        }
        if (found) break;
        totalOffset += n;
        if (n == BUFFER_SIZE) {
            lseek(fd, -(targetLength - 1), SEEK_CUR);
            totalOffset -= (targetLength - 1);
        }
    }
    close(fd);
    return found;
}

int main(int argc, char* argv[]) {
    char *DEBUG = getenv("LAB1DEBUG");
    int debugMode = 0;
    if (DEBUG) {
        fprintf(stderr, "Включен вывод отладочных сообщений\n");
        debugMode = 1;
    }

    int opt;
    char *author = "Пахомов Владимир Юрьевич, гр. N3250\nВариант: 1";
    char *help = "Использование: lab1vypN3250 [опции] <каталог> <цель_поиска>\nОпции:\n  -v, --version  Вывод версии и информации об авторе\n  -h, --help     Вывод этой справки\n";


    static struct option longopts[] = {
        {"version", no_argument, 0, 'v'},
        {"help", no_argument, 0, 'h'},
        {0, 0, 0, 0},
    };

    while ((opt = getopt_long(argc, argv, "vh", longopts, NULL)) != -1) {
        if (opt == 'v') {
            printf("%s\n", author);
            return 0;
        }
        else if (opt == 'h') {
            printf("%s\n", help);
            return 0;
        }
        else {
            fprintf(stderr, "Введены неизвестные опции. Используйте -h для справки\n");
            return 1;
        }
    }

    if (argc - optind < 2) {
        fprintf(stderr, "Ошибка: Необходимо ввести название каталога и цель поиска\n");
        printf("%s\n", help);
        return 1;
    }

    char *searchDir = argv[optind++];
    char *searchString = argv[optind];

    unsigned char targetBytes[256];
    int targetLen = hexToBytes(searchString, targetBytes);
    if (targetLen <= 0) {
        fprintf(stderr, "Ошибка: Неверный формат HEX\n");
        return 1;
    }

    StackNode *dirsStack = NULL;
    push(&dirsStack, searchDir);

    while (dirsStack != NULL) {
        char *currentDir = pop(&dirsStack);
        int fd = open(currentDir, O_RDONLY | O_DIRECTORY);

        if (fd == -1) {
            fprintf(stderr, "Ошибка доступа к каталогу %s: %s\n", currentDir, strerror(errno));
            free(currentDir);
            continue;
        }

        char buffer[BUFFER_SIZE];
        int nread;
        while ((nread = syscall(SYS_getdents64, fd, buffer, BUFFER_SIZE)) > 0) {
            for (int bpos = 0; bpos < nread; ) {
                struct linux_dirent64 *d = (struct linux_dirent64 *)(buffer + bpos);

                if (strcmp(d->d_name, ".") == 0 || strcmp(d->d_name, "..") == 0) {
                    bpos += d->d_reclen;
                    continue;
                }

                char fullPath[MAX_PATH];
                snprintf(fullPath, MAX_PATH, "%s/%s", currentDir, d->d_name);

                if (d->d_type == DT_DIR) {
                    push(&dirsStack, fullPath);
                } else if (d->d_type == DT_REG) {
                    if (search(fullPath, targetBytes, targetLen, debugMode)) {
                        printf("%s\n", fullPath);
                    }
                }

                bpos += d->d_reclen;
            }       
        }
        close(fd);
        free(currentDir);
    }


    return 0;
}