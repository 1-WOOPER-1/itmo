#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include "plugin_api.h"

static uint32_t reverseIP(uint32_t v) {
    return ((v >> 24) & 0xFF) | ((v >> 8) & 0xFF00) | 
           ((v << 8) & 0xFF0000) | ((v << 24) & 0xFF000000);
}

static int parse_ipv4(const char *str, uint32_t *out_be) {
    unsigned int b[4];
    char tail[2];
    
    int dots = 0;
    for (const char *p = str; *p; p++) {
        if (*p == '.') dots++;
    }
    if (dots != 3) return 0;

    if (sscanf(str, "%u.%u.%u.%u%1s", &b[0], &b[1], &b[2], &b[3], tail) != 4) {
        return 0;
    }

    for (int i = 0; i < 4; i++) {
        if (b[i] > 255) return 0;
    }

    unsigned char *p = (unsigned char *)out_be;
    p[0] = (unsigned char)b[0];
    p[1] = (unsigned char)b[1];
    p[2] = (unsigned char)b[2];
    p[3] = (unsigned char)b[3];

    return 1;
}

static struct plugin_option my_options[] = {
    {
        {"ipv4-addr-bin", required_argument, 0, 0},
        "Поиск IPv4 адреса в бинарном виде (BE/LE)"
    }
};

static struct plugin_info my_info = {
    "Плагин поиска бинарной IPv4 строки",
    "Пахомов Владимир Юрьевич, гр. N3250\nВариант: 19",
    1,
    my_options
};

int plugin_get_info(struct plugin_info* ppi) {
    if (!ppi) return -1;
    *ppi = my_info;
    return 0;
}

int plugin_process_file(const char *fname, struct option in_opts[], size_t in_opts_len) {
    int debug = (getenv("LAB2DEBUG") != NULL);

    for (size_t i = 0; i < in_opts_len; i++) {
        if (strcmp(in_opts[i].name, "ipv4-addr-bin") == 0) {
            const char *ip_str = (const char *)in_opts[i].flag;
            uint32_t be_val = 0;

            if (!parse_ipv4(ip_str, &be_val)) {
                fprintf(stderr, "Ошибка: некорректный формат IPv4: %s\n", ip_str);
                return -1;
            }

            uint32_t le_val = reverseIP(be_val);
            int fd = open(fname, O_RDONLY);
            if (fd < 0) return 1;

            unsigned char buf[4096];
            ssize_t n;
            off_t total_read = 0;
            int found = 0;

            while ((n = read(fd, buf, sizeof(buf))) > 0) {
                for (int j = 0; j <= (int)n - 4; j++) {
                    uint32_t chunk;
                    memcpy(&chunk, &buf[j], 4);
                    if (chunk == be_val || chunk == le_val) {
                        if (debug) {
                            fprintf(stderr, "\n[DEBUG] Плагин libvypN3250: Найден IP %s (%s) по смещению %ld в файле %s\n", 
                                     ip_str, chunk == be_val ? "big-endian" : "litte-endian", (long)(total_read + j), fname);
                        }
                        found = 1;
                        break;
                    }
                }
                if (found) break;

                if (n == (ssize_t)sizeof(buf)) {
                    off_t back_step = 3;
                    lseek(fd, -back_step, SEEK_CUR);
                    total_read += (n - back_step);
                } else {
                    total_read += n;
                }
            }
            close(fd);

            if (!found) return 1;
        }
    }
    return 0;
}