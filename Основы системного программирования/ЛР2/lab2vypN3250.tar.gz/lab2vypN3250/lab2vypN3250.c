#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <dlfcn.h>
#include <errno.h>
#include <getopt.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/syscall.h>
#include <libgen.h>
#include <stdint.h>
#include <sys/stat.h>
#include "plugin_api.h"

#define INITIAL_BUFFER_SIZE 8192

typedef struct option_group {
    struct option *opts;
    size_t count;
} option_group_t;

typedef struct loaded_plugin {
    void *handle;
    struct plugin_info info;
    int (*process_file)(const char *fname, struct option in_opts[], size_t in_opts_len);
    
    option_group_t *groups;
    size_t groups_count;
} loaded_plugin_t;

typedef struct StackNode {
    char *path;
    struct StackNode *next;
} StackNode;

void push(StackNode **top, const char *path) {
    StackNode *node = malloc(sizeof(StackNode));
    if (!node) exit(1);
    node->path = strdup(path);
    node->next = *top;
    *top = node;
}

char *pop(StackNode **top) {
    if (*top == NULL) return NULL;
    StackNode *node = *top;
    char *path = node->path;
    *top = node->next;
    free(node);
    return path;
}

struct linux_dirent64 {
    unsigned long long d_ino;
    long long          d_off;
    unsigned short     d_reclen;
    unsigned char      d_type;
    char               d_name[];
};

void deinit_all(loaded_plugin_t *plugins, size_t count, char *p_dir, struct option *l_opts) {
    for (size_t i = 0; i < count; i++) {
        for (size_t g = 0; g < plugins[i].groups_count; g++) {
            for (size_t j = 0; j < plugins[i].groups[g].count; j++) {
                if (plugins[i].groups[g].opts[j].flag) {
                    free(plugins[i].groups[g].opts[j].flag);
                }
            }
            free(plugins[i].groups[g].opts);
        }
        free(plugins[i].groups);
        dlclose(plugins[i].handle);
    }
    if (plugins) free(plugins);
    if (p_dir) free(p_dir);
    if (l_opts) free(l_opts);
}

int main(int argc, char *argv[]) {
    int op_and = 1, op_not = 0;
    char *plugin_dir = NULL;
    
    char *exe_path = malloc(4096);
    ssize_t rlen = readlink("/proc/self/exe", exe_path, 4095);
    if (rlen != -1) {
        exe_path[rlen] = '\0';
        plugin_dir = strdup(dirname(exe_path));
    } else {
        plugin_dir = strdup(".");
    }
    free(exe_path);

    loaded_plugin_t *plugins = NULL;
    size_t plugins_count = 0;

    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "-P") == 0 && i + 1 < argc) {
            free(plugin_dir);
            plugin_dir = strdup(argv[i+1]);
        }
    }

    DIR *d = opendir(plugin_dir);
    if (d) {
        struct dirent *dir;
        while ((dir = readdir(d)) != NULL) {
            if (strstr(dir->d_name, ".so")) {
                char *full_p = malloc(strlen(plugin_dir) + strlen(dir->d_name) + 2);
                sprintf(full_p, "%s/%s", plugin_dir, dir->d_name);
                void *h = dlopen(full_p, RTLD_LAZY);
                free(full_p);
                if (h) {
                    int (*gi)(struct plugin_info*) = dlsym(h, "plugin_get_info");
                    int (*pf)(const char*, struct option[], size_t) = dlsym(h, "plugin_process_file");
                    if (gi && pf) {
                        plugins = realloc(plugins, sizeof(loaded_plugin_t) * (plugins_count + 1));
                        plugins[plugins_count].handle = h;
                        plugins[plugins_count].process_file = pf;
                        plugins[plugins_count].groups = NULL;
                        plugins[plugins_count].groups_count = 0;
                        gi(&plugins[plugins_count].info);
                        plugins_count++;
                    } else { dlclose(h); }
                }
            }
        }
        closedir(d);
    }

    size_t total_opts = 3; 
    for(size_t i=0; i<plugins_count; i++) total_opts += plugins[i].info.sup_opts_len;
    struct option *long_options = calloc(total_opts, sizeof(struct option));

    int opt_idx = 0;
    long_options[opt_idx++] = (struct option){"version", no_argument, 0, 'v'};
    long_options[opt_idx++] = (struct option){"help", no_argument, 0, 'h'};
    for (size_t i = 0; i < plugins_count; i++) {
        for (size_t j = 0; j < plugins[i].info.sup_opts_len; j++)
            long_options[opt_idx++] = plugins[i].info.sup_opts[j].opt;
    }

    int opt, l_idx = 0;
    while ((opt = getopt_long(argc, argv, "P:AONvh", long_options, &l_idx)) != -1) {
        if (opt == 'v') {
            printf("Программа lab2vypN3250\n");
            printf("Пахомов Владимир Юрьевич, гр. N3250\nВариант: 19\n");
            deinit_all(plugins, plugins_count, plugin_dir, long_options); return 0;
        }
        else if (opt == 'h') {
            printf("Использование: lab2vypN3250 [опции] <каталог>\n");
            printf("Опции:\n  -v, --version  Вывод информации об авторе\n  -h, --help     Вывод этой справки\n");
            printf("  -A             Логическое И\n  -O             Логическое OR\n  -N             Логическое NOT\n  -P <каталог>   Указать каталог с плагинами\n");
            deinit_all(plugins, plugins_count, plugin_dir, long_options); return 0;
        }
        else if (opt == 'A') op_and = 1;
        else if (opt == 'O') op_and = 0;
        else if (opt == 'N') op_not = 1;
        else if (opt == 'P') continue;
        else if (opt == 0) {
            for (size_t i = 0; i < plugins_count; i++) {
                for (size_t j = 0; j < plugins[i].info.sup_opts_len; j++) {
                    if (strcmp(long_options[l_idx].name, plugins[i].info.sup_opts[j].opt.name) == 0) {
                        
                        int need_new_group = 0;
                        if (plugins[i].groups_count > 0) {
                            size_t last_g = plugins[i].groups_count - 1;
                            for (size_t k = 0; k < plugins[i].groups[last_g].count; k++) {
                                if (strcmp(plugins[i].groups[last_g].opts[k].name, long_options[l_idx].name) == 0) {
                                    need_new_group = 1;
                                    break;
                                }
                            }
                        } else {
                            need_new_group = 1;
                        }

                        if (need_new_group) {
                            plugins[i].groups = realloc(plugins[i].groups, sizeof(option_group_t) * (plugins[i].groups_count + 1));
                            plugins[i].groups[plugins[i].groups_count].opts = NULL;
                            plugins[i].groups[plugins[i].groups_count].count = 0;
                            plugins[i].groups_count++;
                        }

                        size_t cur_g = plugins[i].groups_count - 1;
                        plugins[i].groups[cur_g].opts = realloc(plugins[i].groups[cur_g].opts, sizeof(struct option) * (plugins[i].groups[cur_g].count + 1));
                        
                        struct option new_opt = plugins[i].info.sup_opts[j].opt;
                        new_opt.flag = optarg ? (int*)strdup(optarg) : NULL;
                        
                        plugins[i].groups[cur_g].opts[plugins[i].groups[cur_g].count] = new_opt;
                        plugins[i].groups[cur_g].count++;
                    }
                }
            }
        } else {
            fprintf(stderr, "Введены неизвестные опции. Используйте -h для справки\n");
            deinit_all(plugins, plugins_count, plugin_dir, long_options); return 1;
        }
    }

    char *start_dir = (optind < argc) ? argv[optind] : ".";
    DIR *check_d = opendir(start_dir);
    if (!check_d) {
        fprintf(stderr, "Ошибка: '%s': %s\n", start_dir, strerror(errno));
        deinit_all(plugins, plugins_count, plugin_dir, long_options); return 1;
    }
    closedir(check_d);

    StackNode *stack = NULL;
    push(&stack, start_dir);

    while (stack) {
        char *curr = pop(&stack);
        int fd = open(curr, O_RDONLY | O_DIRECTORY);
        if (fd == -1) { free(curr); continue; }

        char *buf = malloc(INITIAL_BUFFER_SIZE);
        long nread;
        while ((nread = syscall(SYS_getdents64, fd, buf, INITIAL_BUFFER_SIZE)) > 0) {
            for (long bpos = 0; bpos < nread; ) {
                struct linux_dirent64 *de = (struct linux_dirent64 *)(buf + bpos);
                if (strcmp(de->d_name, ".") == 0 || strcmp(de->d_name, "..") == 0) { 
                    bpos += de->d_reclen; continue; 
                }
                
                char *fp = malloc(strlen(curr) + strlen(de->d_name) + 2);
                sprintf(fp, "%s/%s", curr, de->d_name);

                if (de->d_type == DT_DIR) {
                    push(&stack, fp);
                    free(fp);
                } else if (de->d_type == DT_REG) {
                    int final = op_and;
                    int run = 0;

                    for (size_t i = 0; i < plugins_count; i++) {
                        for (size_t g = 0; g < plugins[i].groups_count; g++) {
                            run = 1;
                            int res = (plugins[i].process_file(fp, plugins[i].groups[g].opts, plugins[i].groups[g].count) == 0);
                            
                            if (op_and) final &= res;
                            else final |= res;
                        }
                    }
                    if (op_not) final = !final;
                    if (final || !run) printf("%s\n", fp);
                    free(fp);
                } else {
                    free(fp);
                }
                bpos += de->d_reclen;
            }
        }
        free(buf); 
        close(fd); 
        free(curr);
    }
    
    deinit_all(plugins, plugins_count, plugin_dir, long_options);
    return 0;
}
