#include <sys/stat.h>
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <signal.h>
#include <errno.h>
#include <time.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/mman.h>
#include <netinet/in.h>
#include <arpa/inet.h>

typedef struct {
    time_t start_time;
    unsigned long success_count;
    unsigned long error_count;
} ServerStats;

volatile sig_atomic_t keep_running = 1;
volatile sig_atomic_t dump_stats = 0;

ServerStats *stats = NULL;
char *log_path = "/tmp/lab3.log";
int debug = 0;

void write_log(const char *message, int is_debug_msg) {
    if (is_debug_msg && !debug) {
        return;
    }

    FILE *f = fopen(log_path, "a");
    if (!f) {
        return;
    }

    time_t now = time(NULL);
    struct tm *tm_info = localtime(&now);
    char time_buf[26];
    strftime(time_buf, sizeof(time_buf), "%d.%m.%y %H:%M:%S", tm_info);

    fprintf(f, "[%s] %s\n", time_buf, message);
    fclose(f);
}

void print_statistics(void) {
    if (stats == NULL) return;

    time_t now = time(NULL);
    double elapsed = difftime(now, stats->start_time);

    char stat_buf[256];
    snprintf(stat_buf, sizeof(stat_buf),
             "--- СТАТИСТИКА РАБОТЫ СЕРВЕРА ---\n"
             "Время работы: %.0f сек\n"
             "Успешно обслужено запросов: %lu\n"
             "Запросов с ошибками: %lu\n"
             "---------------------------------",
             elapsed, stats->success_count, stats->error_count);

    write_log(stat_buf, 0);

    fprintf(stderr, "%s\n", stat_buf);
}

void handle_signal(int sig) {
    if (sig == SIGINT || sig == SIGTERM || sig == SIGQUIT) {
        keep_running = 0;
    } else if (sig == SIGUSR1) {
        dump_stats = 1;
    }
}

void handle_sigchld(int sig) {
    (void)sig;
    int saved_errno = errno;
    while (waitpid(-1, NULL, WNOHANG) > 0);
    errno = saved_errno;
}

void daemonize(void) {
    pid_t pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    if (pid > 0) {
        exit(EXIT_SUCCESS);
    }

    if (setsid() < 0) {
        perror("setsid");
        exit(EXIT_FAILURE);
    }

    pid = fork();
    if (pid < 0) exit(EXIT_FAILURE);
    if (pid > 0) exit(EXIT_SUCCESS);

    umask(0);
    if (chdir("/") < 0) {
        perror("chdir");
        exit(EXIT_FAILURE);
    }

    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    open("/dev/null", O_RDONLY);
    open("/dev/null", O_WRONLY);
    open("/dev/null", O_RDWR);
}

int count_decimal_digits(long long val) {
    if (val == 0) return 1;
    unsigned long long abs_val = (val < 0) ? -val : val;
    int count = 0;
    while (abs_val > 0) {
        count++;
        abs_val /= 10;
    }
    return count;
}

typedef struct {
    long long value;
    int digits;
    int original_index;
} NumberItem;

int compare_items(const void *a, const void *b) {
    const NumberItem *ia = (const NumberItem *)a;
    const NumberItem *ib = (const NumberItem *)b;
    if (ia->digits != ib->digits) {
        return ib->digits - ia->digits;
    }
    return ia->original_index - ib->original_index;
}

char *process_request(const char *request, size_t *out_len) {
    char *req_copy = strdup(request);
    if (!req_copy) {
        *out_len = snprintf(NULL, 0, "ERROR 2\n");
        char *err_res = malloc(*out_len + 1);
        if (err_res) sprintf(err_res, "ERROR 2\n");
        return err_res;
    }

    size_t items_cap = 16;
    size_t items_count = 0;
    NumberItem *items = malloc(items_cap * sizeof(NumberItem));
    if (!items) {
        free(req_copy);
        *out_len = snprintf(NULL, 0, "ERROR 2\n");
        char *err_res = malloc(*out_len + 1);
        if (err_res) sprintf(err_res, "ERROR 2\n");
        return err_res;
    }

    char *saveptr;
    char *token = strtok_r(req_copy, " \t\v\f\r\n", &saveptr);
    int has_invalid_tokens = 0;

    while (token != NULL) {
        char *endptr;
        long long val = strtoll(token, &endptr, 0);

        if (*endptr != '\0' || endptr == token) {
            has_invalid_tokens = 1;
            break;
        }

        if (items_count >= items_cap) {
            items_cap *= 2;
            NumberItem *temp = realloc(items, items_cap * sizeof(NumberItem));
            if (!temp) {
                has_invalid_tokens = 2;
                break;
            }
            items = temp;
        }

        items[items_count].value = val;
        items[items_count].digits = count_decimal_digits(val);
        items[items_count].original_index = (int)items_count;
        items_count++;

        token = strtok_r(NULL, " \t\v\f\r\n", &saveptr);
    }

    free(req_copy);

    char *res_str = NULL;
    if (has_invalid_tokens == 1 || items_count == 0) {
        stats->error_count++;
        *out_len = asprintf(&res_str, "ERROR 1\n");
    } else if (has_invalid_tokens == 2) {
        stats->error_count++;
        *out_len = asprintf(&res_str, "ERROR 2\n");
    } else {
        qsort(items, items_count, sizeof(NumberItem), compare_items);

        size_t res_cap = 128;
        res_str = malloc(res_cap);
        if (!res_str) {
            stats->error_count++;
            *out_len = asprintf(&res_str, "ERROR 2\n");
        } else {
            size_t res_len = 0;
            res_str[0] = '\0';

            for (size_t i = 0; i < items_count; i++) {
                char num_buf[32];
                int printed = snprintf(num_buf, sizeof(num_buf), "%lld", items[i].value);

                while (res_len + printed + 2 > res_cap) {
                    res_cap *= 2;
                    char *temp = realloc(res_str, res_cap);
                    if (!temp) {
                        free(res_str);
                        stats->error_count++;
                        *out_len = asprintf(&res_str, "ERROR 2\n");
                        free(items);
                        return res_str;
                    }
                    res_str = temp;
                }

                strcpy(res_str + res_len, num_buf);
                res_len += printed;

                if (i < items_count - 1) {
                    res_str[res_len++] = ' ';
                } else {
                    res_str[res_len++] = '\n';
                }
                res_str[res_len] = '\0';
            }
            stats->success_count++;
            *out_len = res_len;
        }
    }

    free(items);
    return res_str;
}

int main(int argc, char *argv[]) {
    debug = (getenv("lab3DEBUG") != NULL);

    int wait_time = 0;
    int is_daemon = 0;
    char *address = "127.0.0.1";
    int port = 12345;

    char *env_address = getenv("lab3ADDR");
    char *env_port = getenv("lab3PORT");
    char *env_log = getenv("lab3LOGFILE");
    char *env_wait = getenv("lab3WAIT");

    if (env_address != NULL) address = env_address;
    if (env_log != NULL) log_path = env_log;
    
    if (env_port != NULL) {
        char *endptr;
        long val = strtol(env_port, &endptr, 10);
        if (*endptr == '\0' && val > 0 && val <= 65535) port = (int)val;
    }
    if (env_wait != NULL) {
        char *endptr;
        long val = strtol(env_wait, &endptr, 10);
        if (*endptr == '\0' && val >= 0) wait_time = (int)val;
    }

    stats = mmap(NULL, sizeof(ServerStats), PROT_READ | PROT_WRITE,
                 MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (stats == MAP_FAILED) {
        perror("mmap");
        return 1;
    }
    stats->start_time = time(NULL);
    stats->success_count = 0;
    stats->error_count = 0;

    static struct option longopts[] = {
        {"wait", required_argument, NULL, 'w'},
        {"daemon", no_argument, NULL, 'd'},
        {"log", required_argument, NULL, 'l'},
        {"address", required_argument, NULL, 'a'},
        {"port", required_argument, NULL, 'p'},
        {"version", no_argument, NULL, 'v'},
        {"help", no_argument, NULL, 'h'},
        {NULL, 0, NULL, 0}
    };

    char *author = "Сервер: Пахомов Владимир Юрьевич, гр. N3250\nВариант: 5\n";
    char *help = "Использование: ./lab3vypN3250_server [опции]\n"
                 "Опции:\n"
                 "  -a, --address  IP-адрес для прослушивания (по умолчанию: 127.0.0.1)\n"
                 "  -p, --port     Порт для прослушивания (по умолчанию: 12345)\n"
                 "  -l, --log      Путь к лог-файлу (по умолчанию: /tmp/lab3.log)\n"
                 "  -w, --wait     Имитация работы (задержка N секунд)\n"
                 "  -d, --daemon   Запуск в режиме демона\n"
                 "  -v, --version  Вывод версии и информации об авторе\n"
                 "  -h, --help     Вывод этой справки\n";

    int opt;
    while ((opt = getopt_long(argc, argv, "w:dl:a:p:vh", longopts, NULL)) != -1) {
        switch (opt) {
            case 'a':
                address = optarg;
                break;
            case 'p': {
                char *endptr;
                long val = strtol(optarg, &endptr, 10);
                if (*endptr == '\0' && val > 0 && val <= 65535) port = (int)val;
                break;
            }
            case 'l':
                log_path = optarg;
                break;
            case 'w': {
                char *endptr;
                long val = strtol(optarg, &endptr, 10);
                if (*endptr == '\0' && val >= 0) wait_time = (int)val;
                break;
            }
            case 'd':
                is_daemon = 1;
                break;
            case 'v':
                printf("%s", author);
                munmap(stats, sizeof(ServerStats));
                return 0;
            case 'h':
                printf("%s", help);
                munmap(stats, sizeof(ServerStats));
                return 0;
            default:
                fprintf(stderr, "%s", help);
                munmap(stats, sizeof(ServerStats));
                return 1;
        }
    }


    struct in_addr test_addr;
    if (inet_pton(AF_INET, address, &test_addr) <= 0) {
        fprintf(stderr, "Ошибка: некорректный IP-адрес '%s'\n", address);
        return 1;
    }

    if (is_daemon) {
        daemonize();
    }

    write_log("--- СЕРВЕР ЗАПУЩЕН ---", 0);
    char start_info[256];
    snprintf(start_info, sizeof(start_info), "Слушаем на %s:%d, Имитация ожидания: %d сек", address, port, wait_time);
    write_log(start_info, 0);

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = handle_signal;
    sigemptyset(&sa.sa_mask);
    
    sigaction(SIGINT, &sa, NULL);
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGQUIT, &sa, NULL);
    sigaction(SIGUSR1, &sa, NULL);

    struct sigaction sa_chld;
    memset(&sa_chld, 0, sizeof(sa_chld));
    sa_chld.sa_handler = handle_sigchld;
    sigemptyset(&sa_chld.sa_mask);
    sa_chld.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    sigaction(SIGCHLD, &sa_chld, NULL);

    int listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_fd < 0) {
        write_log("Ошибка при создании сокета", 0);
        munmap(stats, sizeof(ServerStats));
        return 1;
    }

    int optval = 1;
    setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval));

    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    inet_pton(AF_INET, address, &serv_addr.sin_addr);

    if (bind(listen_fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("Ошибка при привязке сокета (bind)");
        write_log("Ошибка при привязке сокета (bind)", 0);
        close(listen_fd);
        munmap(stats, sizeof(ServerStats));
        return 1;
    }

    if (listen(listen_fd, 10) < 0) {
        perror("Ошибка при вызове listen");
        write_log("Ошибка при вызове listen", 0);
        close(listen_fd);
        munmap(stats, sizeof(ServerStats));
        return 1;
    }

    while (keep_running) {
        if (dump_stats) {
            print_statistics();
            dump_stats = 0;
        }

        struct sockaddr_in client_addr;
        socklen_t client_len = sizeof(client_addr);
        
        int client_fd = accept(listen_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) {
            if (errno == EINTR) {
                continue;
            }
            write_log("Ошибка при accept", 0);
            continue;
        }

        char client_ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, sizeof(client_ip));
        
        char conn_msg[128];
        snprintf(conn_msg, sizeof(conn_msg), "Новое подключение с адреса: %s", client_ip);
        write_log(conn_msg, 0);

        pid_t pid = fork();
        if (pid < 0) {
            write_log("Ошибка при вызове fork()", 0);
            close(client_fd);
        } else if (pid == 0) {
            close(listen_fd);

            if (wait_time > 0) {
                char wait_msg[128];
                snprintf(wait_msg, sizeof(wait_msg), "[DEBUG] Имитация работы: задержка %d сек...", wait_time);
                write_log(wait_msg, 1);
                sleep(wait_time);
            }

            size_t req_cap = 128;
            size_t req_len = 0;
            char *request = malloc(req_cap);
            if (!request) {
                close(client_fd);
                exit(EXIT_FAILURE);
            }

            while (1) {
                if (req_len + 64 >= req_cap) {
                    req_cap *= 2;
                    char *temp = realloc(request, req_cap);
                    if (!temp) break;
                    request = temp;
                }
                ssize_t n = read(client_fd, request + req_len, 64);
                if (n <= 0) break;
                req_len += n;
            }
            request[req_len] = '\0';

            char req_log[256];
            snprintf(req_log, sizeof(req_log), "Получен запрос от %s: %s", client_ip, request);
            write_log(req_log, 1);

            size_t res_len = 0;
            char *response = process_request(request, &res_len);

            if (response) {
                write(client_fd, response, res_len);
                free(response);
            }

            free(request);
            close(client_fd);

            char dis_msg[128];
            snprintf(dis_msg, sizeof(dis_msg), "Завершено обслуживание запроса от %s", client_ip);
            write_log(dis_msg, 0);

            exit(EXIT_SUCCESS);
        } else {
            close(client_fd);
        }
    }

    write_log("--- СЕРВЕР ЗАВЕРШАЕТ РАБОТУ ---", 0);
    print_statistics();

    close(listen_fd);
    munmap(stats, sizeof(ServerStats));

    return 0;
}