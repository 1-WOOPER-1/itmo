#include <getopt.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


int main(int argc, char *argv[]) {
    int debug = (getenv("lab3DEBUG") != NULL);

    char *address = "127.0.0.1";
    int port = 12345;

    char *env_address = getenv("lab3ADDR");
    char *env_port = getenv("lab3PORT");
    char *endptr;


    if (env_address != NULL) address = env_address;
    if (env_port != NULL) {
        long val = strtol(env_port, &endptr, 10);
        if (*endptr == '\0' && val > 0 && val <= 65535) {
            port = (int)val;
        } else {
            fprintf(stderr, "Ошибка: неверный формат порта: %s\n", env_port);
            return 1;
        }
    }

    static struct option longopts[] = {
        {"address", required_argument, NULL, 'a'},
        {"port", required_argument, NULL, 'p'},
        {"verbose", no_argument, NULL, 'v'},
        {"help", no_argument, NULL, 'h'},
        {NULL, 0, NULL, 0}
    };


    char *author = "Клиент: Пахомов Владимир Юрьевич, гр. N3250\nВариант: 5\n";
    char *help = "Использование: ./lab3vypN3250_client [опции] [числа...]\n"
                 "Опции:\n"
                 "  -a, --address  IP-адрес сервера (по умолчанию 127.0.0.1)\n"
                 "  -p, --port     Порт сервера (по умолчанию 12345)\n"
                 "  -v, --version  Вывод версии и информации об авторе\n"
                 "  -h, --help     Вывод этой справки\n";
    
    int opt;
    while ((opt = getopt_long(argc, argv, "a:p:vh", longopts, NULL)) != -1) {
        switch (opt) {
            case 'a':
                address = optarg;
                break;
            case 'p': {
                char *endptr;
                long val = strtol(optarg, &endptr, 10);
                if (*endptr != '\0' || val <= 0 || val > 65535) {
                    fprintf(stderr, "Ошибка: некорректное значение порта '%s'. Должно быть число от 1 до 65535.\n", optarg);
                    return 1;
                }
                port = (int)val;
                break;
            }
            case 'v':
                printf("%s", author);
                return 0;
            case 'h':
                printf("%s", help);
                return 0;
            default:
                fprintf(stderr, "%s", help);
                return 1;
        }
    }

    if (debug) {
        fprintf(stderr,  "[DEBUG] Подключение к %s:%d\n", address, port);
    }

    struct in_addr test_addr;
    if (inet_pton(AF_INET, address, &test_addr) <= 0) {
        fprintf(stderr, "Ошибка: некорректный IP-адрес '%s'\n", address);
        return 1;
    }

    size_t query_cap = 128;
    char *query = malloc(query_cap);
    if (query == NULL) {
        fprintf(stderr, "Ошибка: не удалось выделить память для запроса\n");
        return 1;
    }
    query[0] = '\0';
    size_t query_len = 0;

    if (optind < argc) {
        for (int i = optind; i < argc; i++) {
            char *endptr;
            strtol(argv[i], &endptr, 0);

            if (*endptr != '\0' || endptr == argv[i]) {
                fprintf(stderr, "Ошибка: некорректное число '%s'.\n", argv[i]);
                free(query);
                return 1;
            }

            if (debug) {
                fprintf(stderr, "[DEBUG] Число: %s\n", argv[i]);
            }

            size_t arg_len = strlen(argv[i]);
            while (query_len + arg_len + 2 > query_cap) {
                query_cap *= 2;
                char *temp = realloc(query, query_cap);
                if (temp == NULL) {
                    fprintf(stderr, "Ошибка: не удалось выделить память для запроса\n");
                    free(query);
                    return 1;
                }
                query = temp;
            }

            strcpy(query + query_len, argv[i]);
            query_len += arg_len;

            if (i < argc - 1) {
                query[query_len++] = ' ';
            } else {
                query[query_len++] = '\n';
            }
            query[query_len] = '\0';
        }
    } else {
        if (debug) {
            fprintf(stderr, "[DEBUG] Аргументы не переданы. Ожидание ввода из stdin...\n");
        }

        size_t cap = 128;
        size_t buf_len = 0;
        char *buf = malloc(cap);
        if (buf == NULL) {
            fprintf(stderr, "Ошибка: не удалось выделить память для ввода\n");
            free(query);
            return 1;
        }

        int c;
        while ((c = fgetc(stdin)) != EOF && c != '\n') {
            if (buf_len + 2 >= cap) {
                cap *= 2;
                char *temp = realloc(buf, cap);
                if (temp == NULL) {
                    fprintf(stderr, "Ошибка: не удалось выделить память для ввода\n");
                    free(buf);
                    free(query);
                    return 1;
                }
                buf = temp;
            }
            buf[buf_len++] = (char)c;
        }

        buf[buf_len++] = '\n';
        buf[buf_len] = '\0';

        free(query);
        query = buf;
        query_len = buf_len;

        char *query_copy = malloc(query_len + 1);
        if (query_copy == NULL) {
            fprintf(stderr, "Ошибка: не удалось выделить память для валидации\n");
            free(query);
            return 1;
        }

        strcpy(query_copy, query);

        char *token = strtok(query_copy, " \t\v\f\r\n");
        if (token == NULL) {
            fprintf(stderr, "Ошибка: пустой запрос\n");
            free(query);
            free(query_copy);
            return 1;
        }

        while (token != NULL) {
            char *endptr;
            strtol(token, &endptr, 0);
            if (*endptr != '\0' || endptr == token) {
                fprintf(stderr, "Ошибка: некорректное число '%s'\n", token);
                free(query);
                free(query_copy);
                return 1;
            }
            token = strtok(NULL, " \t\v\f\r\n");
        }
        free(query_copy);

    }

    if (debug) {
        fprintf(stderr, "[DEBUG] Сформированный запрос: %s", query);
    }

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        fprintf(stderr, "Ошибка: не удалось создать сокет\n");
        free(query);
        return 1;
    }
    
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    if (inet_pton(AF_INET, address, &server_addr.sin_addr) <= 0) {
        fprintf(stderr, "Ошибка: некорректный IP-адрес '%s'\n", address);
        free(query);
        close(sock);
        return 1;
    }

    if (debug) {
        fprintf(stderr, "[DEBUG] Установка TCP соедниениня с %s:%d...\n", address, port);
    }

    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        fprintf(stderr, "Ошибка: не удалось подключиться к серверу %s:%d\n", address, port);
        free(query);
        close(sock);
        return 1;
    }

    if (debug) {
        fprintf(stderr, "[DEBUG] Соединение установлено. Отправка запроса...\n");
    }

    ssize_t sent = write(sock, query, query_len);
    if (sent < 0) { 
        fprintf(stderr, "Ошибка: не удалось отправить запрос\n");
        free(query);
        close(sock);
        return 1;
    }

    if (debug) {
        fprintf(stderr, "[DEBUG] Запрос отправлен. Ожидание ответа...\n");
    }
    if (shutdown(sock, SHUT_WR) < 0) {
        fprintf(stderr, "Ошибка: не удалось закрыть запись в сокете\n");
        free(query);
        close(sock);
        return 1;
    }

    size_t resp_cap = 128;
    size_t resp_len = 0;
    char *response = malloc(resp_cap);
    if (response == NULL) {
        fprintf(stderr, "Ошибка: не удалось выделить память для ответа\n");
        free(query);
        close(sock);
        return 1;
    }

    while (1) {
        if (resp_len + 64 >= resp_cap) {
            resp_cap *= 2;
            char *temp = realloc(response, resp_cap);
            if (temp == NULL) {
                fprintf(stderr, "Ошибка: не удалось выделить память для ответа\n");
                free(response);
                free(query);
                close(sock);
                return 1;
            }
            response = temp;
        }

        ssize_t received = read(sock, response + resp_len, 64);
        if (received < 0) {
            fprintf(stderr, "Ошибка: не удалось прочитать ответ\n");
            free(response);
            free(query);
            close(sock);
            return 1;
        }
        if (received == 0) {
            break;
        }
        resp_len += received;
    }
    response[resp_len] = '\0';

    if (debug) {
        fprintf(stderr, "[DEBUG] Ответ получен (%zu байт). Закрытие соединения...\n", resp_len);
    }

    printf("%s", response);
    free(response);
    close(sock);
    free(query);

    return 0;

}